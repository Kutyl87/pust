simul = sim("zad1.slx");
hold on
lin = plot(simul.lin.time, simul.lin.signals.values);
dis = stairs(simul.dis.time, simul.dis.signals.values);
hold off

legend([lin, dis], {"transmitancja ciągła", "transmitancja dyskretna"} ,'Location','southeast');
title('Porównanie odpowiedzi skokowej');
xlabel('Czas(s)')
ylabel("Wartość")
print("Porównanie odpowiedzi skokowej.png","-dpng","-r400");