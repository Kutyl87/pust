T0_nom = 5;
K0_nom = 6.6;
y_w = []
K0przezK0nom = [1:0.01:1.2];

for i=1:size(K0przezK0nom, 2)
    [y_t, u_t] = pid_calculation_with_variable(10, K0_nom*K0przezK0nom(i), T0_nom*2)
    y_w(i,1:size(y_t,1))=y_t;
end

a = 11;

K0przezK0nom(a)

figure
hold on
[1:Tp:sim_time+Tp];
p_y = stairs( y_w(a, 1:end), "Blue");
ylabel("y lub u")
xlabel("Czas(s)")
title("Sterowanie dyskretny algorytm PID")
hold off


function [y,u]=pid_calculation_with_variable(set_point, K0, T0)
    Tp = 0.5;

    T1 = 2.08;
    T2 = 4.6;
    B = -T2*K0/(T1-T2);
    A = K0 - B;
    
    a1 = -exp(-Tp/T2) - exp(-Tp/T1);
    a0 = exp(-Tp/T1-Tp/T2);
    b1 = B*(1-exp(-Tp/T2))+ A*(1-exp(-Tp/T1));
    b0 = B*(1-exp(-Tp/T2))*(-exp(-Tp/T1))+ A*(1-exp(-Tp/T1))*(-exp(-Tp/T2));
    
    Kk = 0.3215;
    Tosc = 19.5;
    Kr = 0.6*Kk;
    Ti = 0.5*Tosc;
    Td = 0.12*Tosc;
    
    r0 = Kr*(1+ Tp/(2*Ti) + Td/Tp);
    r1 = Kr*(Tp/(2*Ti) - 2*Td/Tp - 1);
    r2 = Kr*Td/Tp;
    
    sim_time = 100;
    
    u = zeros(sim_time, 1);
    y = zeros(sim_time, 1);
    e = zeros(sim_time, 1);
    
    for i=2:sim_time/Tp
        y(i) = -a1*y(max(1, i-1))-a0*y(max(1, i-2)) + b1*u(max(1, i-((T0/Tp)+1))) + b0*u(max(1, i-((T0/Tp)+2)));
        e(i) = (set_point-y(max(1, i)));
        u(i) = r2*e(max(1, i-2)) + r1*e(max(1, i-1)) + r0*e(i) + u(max(1, i-1));
    end
end