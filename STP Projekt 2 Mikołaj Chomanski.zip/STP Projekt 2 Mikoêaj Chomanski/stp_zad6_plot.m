T0_rel = [1:0.1:2];

Pid_K0_rel = [1.59 1.52 1.47 1.4 1.35 1.3 1.26 1.22 1.18 1.14 1.1];
DMC_K0_rel = [2.05 1.93 1.27 0.59 0.24 0.13 0.09 0.08 0.08 0.13 0.22];
plot(T0_rel, Pid_K0_rel, "RED")
title({"Obszry stabilności regulatora PID"})
ylabel("K0/K0_nom")
xlabel("T0/T0_nom")
ylim([0 2.5])
print("Stabilność PID.png","-dpng","-r400");
figure
plot(T0_rel, DMC_K0_rel, "RED")
title({"Obszry stabilności regulatora DMC"})
ylabel("K0/K0_nom")
xlabel("T0/T0_nom")
ylim([0 2.5])
print("Stabilność DMC.png","-dpng","-r400");