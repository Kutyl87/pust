%% Wyznacznie parametrów PIDa ciągłego
Kr = 0.3215;
Ti = 0;
Td = 0;

regulator = pid(Kr, Ti, Td);
loop = feedback(regulator*con_tran, 1);
hold on
step(loop)
xlim([0 500])
title('Szukanie parametrów PID metodą Zieglera-Nicholas K=0,3215');
xlabel('Czas(s)')
ylabel("Wartość")
hold off
% print("Zieglera_nicholsa.png","-dpng","-r400");


%% Wyznacznie parametrów PIDa dyskretnego
Kk = 0.3215;
Tosc = 19.5;
Kr = 0.6*Kk;
Ti = 0.5*Tosc;
Td = 0.12*Tosc;

r1 = Kr*(1+ Tp/(2*Ti) + Td/Tp);
r2 = Kr*(Tp/(2*Ti) - 2*Td/Tp - 1);
r3 = Kr*Td/Tp;

% %% Test pida
% 
% figure
% regulator = pid(Kr, Ti/1000, Td/1000);
% loop = feedback(regulator*con_tran, 2);
% hold on
% step(loop)
% xlim([0 150])
% title('Test parametrów PIDa ciągłego');
% xlabel('Czas(s)')
% ylabel("Wartość")
% hold off
% % print("Test_pid.png","-dpng","-r400");
