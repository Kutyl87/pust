Tp = 0.5;

K0 = 6.6;
T0 = 5;
T1 = 2.08;
T2 = 4.6;
B = -T2*K0/(T1-T2);
A = K0 - B;

a1 = -exp(-Tp/T2) - exp(-Tp/T1);
a0 = exp(-Tp/T1-Tp/T2);
b1 = B*(1-exp(-Tp/T2))+ A*(1-exp(-Tp/T1));
b0 = B*(1-exp(-Tp/T2))*(-exp(-Tp/T1))+ A*(1-exp(-Tp/T1))*(-exp(-Tp/T2));


con_tran = tf([K0], [T1*T2, T1+T2, 1], 'InputDelay',T0)
dis_tran = tf([b1, b0], [1, a1, a0], Tp, 'InputDelay',T0/Tp)


tran = c2d(con_tran, Tp);

% step(dis_tran)
% figure
% step(con_tran)