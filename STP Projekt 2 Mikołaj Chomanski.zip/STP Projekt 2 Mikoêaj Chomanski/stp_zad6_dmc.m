T0_nom = 5;
K0_nom = 6.6;
% y_w = []
K0przezK0nom = [0.1:0.05:.8];
Tp = 0.5;
sim_time = 80;

for i=1:size(K0przezK0nom, 2)
    [y_t, u_t] = dmc_calculation_with_params(K0_nom*K0przezK0nom(i), T0_nom*1.7);
    y_w(i,1:size(y_t,1))=y_t;
end

% y_w_1 = y_w;
% y_w_12 = y_w;
% y_w_2 = y_w;
a =1;

K0przezK0nom(a)

figure
hold on
[1:Tp:sim_time+Tp];
p_y = stairs( y_w(a, 1:end), "Blue");
ylabel("y lub u")
xlabel("Czas(s)")
title("Sterowanie dyskretny algorytm PID")
hold off


function [y, u] = dmc_calculation_with_params(K0, T0)
    
    % TODO odpowież skoskowa parametry do pierwotnego parametru
    T0_nom = 5;
    K0_nom = 6.6;
    N = 23;
    D = 100;
    Nu = 9;
    lambda = 0.4;
    Tp = 0.5;
    T1 = 2.08;
    T2 = 4.6;
    B = -T2*K0_nom/(T1-T2);
    A = K0_nom - B;
    
    a1 = -exp(-Tp/T2) - exp(-Tp/T1);
    a0 = exp(-Tp/T1-Tp/T2);
    b1 = B*(1-exp(-Tp/T2))+ A*(1-exp(-Tp/T1));
    b0 = B*(1-exp(-Tp/T2))*(-exp(-Tp/T1))+ A*(1-exp(-Tp/T1))*(-exp(-Tp/T2));
    
    y_zad = 10;
    sim_end = 200;
    regulation_sim_time = 2000;
    
    y_step = zeros(1, sim_end+1);
    D1 = ones(1, sim_end-10);
    D1(1) = 0;
    for i=2:sim_end+1
        y_step(i) = -a1*y_step(max(1, i-1))-a0*y_step(max(1, i-2)) + b1*D1(max(1, i-11)) + b0*D1(max(1, i-12));
    end
    s_values = y_step(:, 3:end);
    
    delta_UP = zeros(D-1, 1);
    delta_U = zeros(N, 1);
    y = zeros(regulation_sim_time, 1);
    u = zeros(regulation_sim_time, 1);
    
    M = zeros(N, Nu);
    for i = 1:Nu
        M(i:N, i) = s_values(1, 1:(N-i+1))';
    end
    MP = zeros(N, D-1);
    for i = 1:D-1
        for j= 1:N
            MP(j, i)=s_values(1, j+i)-s_values(1, i);
        end
    end
    
    K = ((M'*M+ eye(Nu ,Nu).*lambda)^-1)*M';
    ke = sum(K(1, 1:end));
    yzad_przeb = ones(regulation_sim_time, 1);
    yzad_przeb(1 : 40, 1) = yzad_przeb(1:40, 1)*10;
    yzad_przeb(41 : 80, 1) = yzad_przeb(41:80, 1)*5;
    yzad_przeb(81 : end, 1) = yzad_przeb(81:end, 1)*12;

    B = -T2*K0/(T1-T2);
    A = K0 - B;
    a1 = -exp(-Tp/T2) - exp(-Tp/T1);
    a0 = exp(-Tp/T1-Tp/T2);
    b1 = B*(1-exp(-Tp/T2))+ A*(1-exp(-Tp/T1));
    b0 = B*(1-exp(-Tp/T2))*(-exp(-Tp/T1))+ A*(1-exp(-Tp/T1))*(-exp(-Tp/T2));
    
    for i=2:regulation_sim_time
        y_zad = yzad_przeb(i);
        y(i) = -a1*y(max(1, i-1))-a0*y(max(1, i-2)) + b1*u(max(1, i-((T0/Tp)+1))) + b0*u(max(1, i-((T0/Tp)+2)));
        Y0 = ones(N, 1).*y(i)+MP*delta_UP;
        delta_U = K*(ones(N, 1).*y_zad-Y0);
        u(i) = u(i-1)+delta_U(1);
        delta_UP(2:D-1) = delta_UP(1:D-2);
        delta_UP(1) = delta_U(1);
    end
end