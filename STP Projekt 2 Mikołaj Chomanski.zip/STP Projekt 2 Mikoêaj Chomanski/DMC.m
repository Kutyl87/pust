%% DMC

y_step = step_response(a1, a0, b1, b0);
stairs([1:Tp:100],y_step);
title({"Odpowieź skokowa"})
ylabel("Wartośc")
xlabel("Czas(s)")
% print("odpowieź skokowa DMC.png","-dpng","-r1200");
figure
Tp_dmc = 1; %as multiplications of objects Tp
N = 60;
D = 100;
Nu = 30;
lambda = 1;
s_data = y_step(1, 1:end);

M = zeros(N, Nu);
for i = 1:Nu
    M(i:N, i) = s_data(1, 1:(N-i+1))';
end

MP = zeros(N, D-1);
for i = 1:D-1
    for j= 1:N
        MP(j, i)=s_data(1, j+i)-s_data(1, i);
    end
end
K = ((M'*M+ eye(Nu ,Nu).*lambda)^-1)*M';

y_zad = 10;
sim_time = 200;

Y0 = zeros(N, 1);
delta_UP=zeros(D-1, 1);
delta_U = zeros(N, 1);
u = zeros(sim_time, 1);
y = zeros(sim_time, 1);

%% kod z macierzami

% for i=2:sim_time
%     y(i) = -a1*y(max(1, i-1))-a0*y(max(1, i-2)) + b1*u(max(1, i-11)) + b0*u(max(1, i-12));
%     Y0 = ones(N, 1).*y(i)+MP*delta_UP;
%     delta_U = K*(ones(N, 1).*y_zad-Y0);
%     u(i) = u(i-1)+delta_U(1);
%     delta_UP(2:D-1) = delta_UP(1:D-2);
%     delta_UP(1) = delta_U(1);
% end
% figure
% stairs(y);
% xlim([0, 100])
% figure
% stairs(u)

%% Kod Z Sumowaniem

y = zeros(sim_time, 1);
u = zeros(sim_time, 1);
ke = sum(K(1, 1:end));
for i=2:sim_time
    y(i) = -a1*y(max(1, i-1))-a0*y(max(1, i-2)) + b1*u(max(1, i-11)) + b0*u(max(1, i-12));
    sum_delta_u = 0;
    for j=1:D-1
        sum_delta_u = sum_delta_u + K(1, 1:end)*MP(1:end, j)*delta_UP(j);
    end
    delta_U(i) = ke*(y_zad-y(i)) - sum_delta_u;
    u(i) = u(i-1)+delta_U(i);
    delta_UP(2:D-1) = delta_UP(1:D-2);
    delta_UP(1) = delta_U(i);
    plot(u)

end

stairs(y);
xlim([0, 100])
figure
stairs(u)


%% Funkcje
function y=step_response(a1, a0, b1, b0)
    y=zeros(1, 201);
    D = ones(1, 201);
    D(1) = 0;
    u_w = []
    for i=2:201
        y(i) = -a1*y(max(1, i-1))-a0*y(max(1, i-2)) + b1*D(max(1, i-11)) + b0*D(max(1, i-12));
        u_w = D(i);
    end
    hold on
    stairs(y);
    stairs(D)
    hold off
    figure
    y = y(:, 3:end);
end