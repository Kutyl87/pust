N_t = [23, 23, 23, 23];
Nu_t = [9, 9, 9, 9];
lambda_t = [0.4, 0.4, 0.4, 0.4];
t_c = 1;

N = N_t(t_c);
D = 100;
Nu = Nu_t(t_c);
lambda = lambda_t(t_c);
[y1,u1]=dmc_calculation(N, D, Nu, lambda);
t_c = t_c + 1;
N = N_t(t_c);
D = 100;
Nu = Nu_t(t_c);
lambda = lambda_t(t_c);
[y2,u2]=dmc_calculation(N, D, Nu, lambda);
t_c = t_c + 1;
N = N_t(t_c);
D = 100;
Nu = Nu_t(t_c);
lambda = lambda_t(t_c);
[y3,u3]=dmc_calculation(N, D, Nu, lambda);
t_c = t_c + 1;
N = N_t(t_c);
D = 100;
Nu = Nu_t(t_c);
lambda = lambda_t(t_c);
[y4,u4]=dmc_calculation(N, D, Nu, lambda);

Tp = 0.5;
regulation_sim_time = 40;
time = [0.5:Tp:regulation_sim_time];
figure
stairs(time, y1, "Red");
hold on
stairs(time, y2, "--Blue");
stairs(time, y3, "--Green");
stairs(time, y4, "--Magenta");
% ylim([-1, 12])
% xlim([9, 12])
title('Wyjścia DMC z różnymi parametrami lambda')
ylabel('y')
xlabel({'Czas(s)'})
legend("lambda = "+lambda_t(1), "lambda = "+lambda_t(2), "lambda = "+lambda_t(3), "lambda = "+lambda_t(4), 'Location', 'southeast')
hold off
% print("Uklad dyskretny z DMC wyjścia lambda mniej","-dpng","-r600")

figure
stairs(time, u1, "Red")
hold on
stairs(time, u2, "--Blue")
stairs(time, u3, "--Green")
stairs(time, u4, "--Magenta")
title('Sterowania DMC z różnymi parametrami lambda')
ylabel('u')
xlabel({'Czas(s)'})
legend("lambda = "+lambda_t(1), "lambda = "+lambda_t(2), "lambda = "+lambda_t(3), "lambda = "+lambda_t(4), 'Location', 'southeast')
hold off
% print("Uklad dyskretny z DMC sterowanie lambda mniej","-dpng","-r600")
