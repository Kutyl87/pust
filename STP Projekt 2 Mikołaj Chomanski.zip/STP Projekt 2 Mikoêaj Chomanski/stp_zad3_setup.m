Kk = 0.3121;
Tosc = 19.5;
Kr = 0.6*Kk;
Ti = 0.5*Tosc;
Td = 0.12*Tosc;