%% Dyskretny PID
% y(k)=-a_1 y(k-1)- a_0 y(k-2)+b_1 u(k-11)+b_0 u(k-12)
% u(k)= r_2 e(k-2) + r_1 e(k-1) + r_0 e(k) + u(k-1)

% Kk = 0.3215;
% Tosc = 19.5;
% Kr = 0.6*Kk;
% Ti = 0.5*Tosc;
% Td = 0.12*Tosc;
% 
% r0 = Kr*(1+ Tp/(2*Ti) + Td/Tp);
% r1 = Kr*(Tp/(2*Ti) - 2*Td/Tp - 1);
% r2 = Kr*Td/Tp;
% 
% sim_time = 100;
% 
% stp = 10;
% 
% u = zeros(sim_time, 1);
% y = zeros(sim_time, 1);
% e = zeros(sim_time, 1);
% 
% for i=2:sim_time/Tp
%     y(i) = -a1*y(max(1, i-1))-a0*y(max(1, i-2)) + b1*u(max(1, i-11)) + b0*u(max(1, i-12));
%     e(i) = (stp-y(max(1, i)));
%     u(i) = r2*e(max(1, i-2)) + r1*e(max(1, i-1)) + r0*e(i) + u(max(1, i-1));
% end
% figure
% hold on
% [1:Tp:sim_time+Tp];
% wart_z = ones(1, sim_time/Tp)*stp;
% wart_z(1) = 0;
% p_y = stairs([1-Tp:Tp:sim_time], y, "Blue");
% p_u = stairs([1-Tp:Tp:sim_time], u, "--Red");
% ylabel("y lub u")
% xlabel("Czas(s)")
% legend([p_y, p_u], {"Wyjście", "Sterowanie"});
% title("Sterowanie dyskretny algorytm PID")
% hold off
% print("Test_param_pid.png","-dpng","-r400");


stp = 10;

[y,u] = pid_calculation(stp);
figure
hold on
sim_time = 100;
[1:Tp:sim_time+Tp];
wart_z = ones(1, sim_time/Tp)*stp;
wart_z(1) = 0;
p_y = stairs([1-Tp:Tp:sim_time], y, "Blue");
p_u = stairs([1-Tp:Tp:sim_time], u, "--Red");
ylabel("y lub u")
xlabel("Czas(s)")
legend([p_y, p_u], {"Wyjście", "Sterowanie"});
title("Sterowanie dyskretny algorytm PID")
hold off
% print("Test_param_pid.png","-dpng","-r400");
